package com.example.gamecurrencyeditor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.ViewGroup
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private var sourceUri: Uri? = null
    private var originalText: String = ""
    private var editedText: String = ""
    private lateinit var status: TextView
    private lateinit var preview: TextView
    private lateinit var amount: EditText
    private lateinit var key: EditText

    private val openFile = 100
    private val saveFile = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFF202536.toInt())
        }
        val title = label("GAME CURRENCY EDITOR", 22f)
        title.setTypeface(null, 1)
        root.addView(title)
        root.addView(label("Работа только с файлами, которые ты сам выберешь. Оригинал не перезаписывается.", 14f))
        val open = Button(this).apply {
            text = "1. Открыть файл сохранения"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, openFile)
            }
        }
        root.addView(open)
        root.addView(label("Название поля валюты (например, coins, money, cash):"))
        key = EditText(this).apply { setText("coins"); hint = "coins" }
        root.addView(key)
        root.addView(label("Новое количество:"))
        amount = EditText(this).apply { setText("999999"); inputType = 2 }
        root.addView(amount)
        val apply = Button(this).apply {
            text = "2. Изменить выбранное поле"
            setOnClickListener { editCurrency() }
        }
        root.addView(apply)
        val save = Button(this).apply {
            text = "3. Сохранить как новый файл"
            setOnClickListener {
                if (editedText.isBlank()) {
                    status.text = "Сначала открой файл и измени поле."
                } else {
                    val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "edited_save.json")
                    }
                    startActivityForResult(i, saveFile)
                }
            }
        }
        root.addView(save)
        status = label("Файл ещё не выбран.")
        root.addView(status)
        preview = label("", 12f)
        val scroll = ScrollView(this)
        scroll.addView(preview)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android but supported for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == openFile) {
            try {
                sourceUri = uri
                contentResolver.openInputStream(uri).use { input ->
                    originalText = BufferedReader(InputStreamReader(input)).readText()
                }
                editedText = ""
                status.text = "Файл открыт. Размер: ${originalText.length} символов."
                preview.text = originalText.take(2500)
            } catch (e: Exception) {
                status.text = "Не удалось прочитать файл: ${e.message}"
            }
        } else if (requestCode == saveFile) {
            try {
                contentResolver.openOutputStream(uri, "w").use { out ->
                    out?.write(editedText.toByteArray(Charsets.UTF_8))
                }
                status.text = "Готово! Изменённая копия сохранена отдельно."
            } catch (e: Exception) {
                status.text = "Не удалось сохранить: ${e.message}"
            }
        }
    }

    private fun editCurrency() {
        if (originalText.isBlank()) {
            status.text = "Сначала выбери файл."
            return
        }
        val field = key.text.toString().trim()
        val value = amount.text.toString().trim()
        if (field.isEmpty() || value.isEmpty() || !value.all { it.isDigit() }) {
            status.text = "Укажи имя поля и целое неотрицательное число."
            return
        }
        // Handles simple JSON numeric properties only; does not alter encrypted/binary saves.
        val pattern = Regex("(\""+Regex.escape(field)+"\"\\s*:\\s*)[0-9]+")
        if (!pattern.containsMatchIn(originalText)) {
            status.text = "Поле '$field' не найдено как обычное числовое поле JSON. Этот формат пока не поддерживается."
            editedText = ""
            return
        }
        editedText = pattern.replace(originalText) { m -> m.groupValues[1] + value }
        status.text = "Поле '$field' изменено на $value. Сохрани копию отдельным файлом."
        preview.text = editedText.take(2500)
    }
}
